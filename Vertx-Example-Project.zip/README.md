
## Eclipse Vert.x 3.8.2

### What is Vert.x?

	Vert.x is a tool-kit for building reactive applications on the JVM.
	Vert.x is event driven and non blocking. This means your app can handle a lot of concurrency using a small number of kernel threads. 
	Vert.x lets your app scale with minimal hardware.
	Vert.x is lightweight - Vert.x core is around 650kB in size.
	Vert.x is fast. Here are some independent numbers.
	Vert.x is not an application server. There's no monolithic Vert.x instance into which you deploy applications. You just run your apps wherever you want to.
	Vert.x is modular - when you need more bits just add the bits you need and nothing more.
	Vert.x is simple but not simplistic. Vert.x allows you to create powerful apps, simply.
	Vert.x is an ideal choice for creating light-weight, high-performance, microservices.
	
### Maven initial setup for Eclipse IDE

	$ mvn dependency:tree
	$ mvn eclipse:eclipse

### From NPM

	$ npm install vertx3-min
	$ npm install vertx3-full

### From Docker

	You can install the full vert.x distribution in a Docker container:
	$ docker run -i -t vertx/vertx3-exec

### From SDKMan
	You can download the full vert.x distributions from SDKMan:
	$ sdk install vertx

### From Homebrew
	The full distribution can be downloaded from Homebrew:
	$ brew install vert.x
	
### Java API
	https://vertx.io/docs/apidocs/

### Java Manual
	https://vertx.io/docs/vertx-core/java/