package com.example.vertx.domain;

import io.vertx.core.Vertx;
import io.vertx.core.VertxOptions;
import io.vertx.core.http.HttpMethod;
import io.vertx.core.http.HttpServer;
import io.vertx.core.http.HttpServerOptions;
import io.vertx.core.http.HttpServerResponse;
import io.vertx.core.streams.Pump;

public class WelcomeServerVerticle {

	public static void main(String[] args) {

		Vertx vertx = Vertx.vertx(new VertxOptions().setWorkerPoolSize(40));

		HttpServerOptions options = new HttpServerOptions().setMaxWebSocketFrameSize(1000000);

		HttpServer server = vertx.createHttpServer(options);
//		server.listen(8080, "myhost.com", res -> {
//			if (res.succeeded()) {
//				System.out.println("Server is now listening!");
//			} else {
//				System.out.println("Failed to bind!");
//			}
//		});

		server.requestHandler(request -> {
			if (request.path().equals("/welcome")) {
			    //file = "index.html";
				System.out.println("requestHandler!!!!!!-@");
				
				HttpServerResponse response = request.response();
				  if (request.method() == HttpMethod.GET) {
				    response.setChunked(true);
				    Pump.pump(request, response).start();
				    request.endHandler(v -> response.end("name", "rahamath S"));
				  } else {
				    response.setStatusCode(400).end();
				  }
			  }  else {
					System.out.println("requestHandler!!!!!!---else");

			  }
		}).listen(8090, "localhost");

	}

}
