package com.example.vertx;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.Future;
import io.vertx.core.Vertx;

import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;

public class WelcomeVerticle extends AbstractVerticle {
	
	private static final Logger logger = LogManager.getLogger(WelcomeVerticle.class);

   
    public static void main(String[] args) {
        Vertx vertx = Vertx.vertx();
        vertx.deployVerticle(new WelcomeVerticle());
    }

    @Override
    public void start(Future<Void> future) {
        logger.debug("Welcome to Vertx");
    }

    @Override
    public void stop() {
    	logger.debug("Shutting down application");
    }
}